package net.xentany.xbossbar.task;

import net.xentany.xbossbar.Main;
import org.bukkit.boss.BossBar;

public class RegularTask extends BossBarTask {

    double separation;
    double progress;
    boolean invert;

    public RegularTask(BossBar bossBar, Main plugin, double seconds, boolean invert) {
        super(bossBar, plugin);
        this.separation = 1.0 / seconds;
        this.progress = invert ? 0.0 : 1.0;
        this.invert = invert;
    }

    @Override
    public void run() {
        if ((invert && progress >= 1.0) || (!invert && progress <= 0)) {
            plugin.getBossBarManager().loadBossBars();
            if (!plugin.getConfig().getBoolean("settings.join-event")) {
                plugin.getBossBarManager().loadBossBars();
            }
        } else {
            bossBar.setProgress(progress);
            progress = invert ? progress + separation : progress - separation;
        }
    }
}