package net.xentany.xbossbar.task;

import net.xentany.xbossbar.Main;
import org.bukkit.boss.BossBar;

public class CombinedTask extends BossBarTask {

    double ticks;
    double tick = 0.0;
    boolean invert;
    boolean still;
    boolean smooth;

    public CombinedTask(BossBar bossBar, Main plugin, double seconds, boolean invert, boolean still, boolean smooth) {
        super(bossBar, plugin);
        this.ticks = seconds * 20.0;
        this.invert = invert;
        this.still = still;
        this.smooth = smooth;
    }

    @Override
    public void run() {
        if (still) {
            if (tick == 0) {
                bossBar.setProgress(1.0);
                tick++;
            } else if (tick >= ticks) {
                plugin.getBossBarManager().loadBossBars();
            } else {
                tick += 20.0;
            }
            return;
        }


        if (tick >= ticks) {
            plugin.getBossBarManager().loadBossBars();
            if (!plugin.getConfig().getBoolean("settings.join-event")) {
                plugin.getBossBarManager().loadBossBars();
            }
        } else {
            double progress;
            if (smooth) {
                progress = invert ? tick / ticks : 1.0 - (tick / ticks);
            } else {
                progress = invert ? 1.0 - (tick / ticks) : tick / ticks;
            }
            bossBar.setProgress(progress);
            tick += smooth ? 1.0 : ticks / 20.0;
        }
    }
}
