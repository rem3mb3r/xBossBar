package net.xentany.xbossbar.manager;

import org.bukkit.configuration.ConfigurationSection;

public class BooleanManager {

    private final ConfigurationSection section;

    public BooleanManager(ConfigurationSection section) {
        this.section = section;
    }

    public boolean get(String key, boolean value) {
        return section.getBoolean(key, value);
    }
}
