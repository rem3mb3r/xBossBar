package net.xentany.xbossbar.task;

import net.xentany.xbossbar.Main;
import org.bukkit.boss.BossBar;
import org.bukkit.scheduler.BukkitRunnable;

public abstract class BossBarTask extends BukkitRunnable {

    protected final BossBar bossBar;
    protected final Main plugin;

    public BossBarTask(BossBar bossBar, Main plugin) {
        this.bossBar = bossBar;
        this.plugin = plugin;
    }

    public abstract void run();
}
