package net.xentany.xbossbar;

import net.xentany.xbossbar.listener.PlayerCommand;
import net.xentany.xbossbar.listener.PlayerJoin;
import net.xentany.xbossbar.manager.BossBarManager;
import net.xentany.xbossbar.util.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Optional;

public class Main extends JavaPlugin {

    private BossBarManager bossBarManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        bossBarManager = new BossBarManager(this);
        bossBarManager.loadBossBars();

        Bukkit.getPluginManager().registerEvents(new PlayerCommand(), this);

        if (getConfig().getBoolean("settings.join-event")) {
            Bukkit.getPluginManager().registerEvents(new PlayerJoin(this), this);
        }

        if (getConfig().getBoolean("settings.bstats")) {
            new Metrics(this, 20129);
        }
    }

    @Override
    public void onDisable() {
        bossBarManager.unloadBossBar();
        bossBarManager = null;
    }

    public BossBarManager getBossBarManager() {
        return bossBarManager;
    }
}