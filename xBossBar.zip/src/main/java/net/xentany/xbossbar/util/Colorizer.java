package net.xentany.xbossbar.util;

import net.md_5.bungee.api.ChatColor;
import org.jetbrains.annotations.NotNull;

import java.util.regex.Pattern;

public class Colorizer {

    public static @NotNull String parse(String input) {
        String text = Pattern.compile("#[a-fA-F0-9]{6}")
                .matcher(input)
                .replaceAll(match -> ChatColor.of(match.group()).toString());
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
