package net.xentany.xbossbar.manager;

import net.xentany.xbossbar.Main;
import net.xentany.xbossbar.task.BossBarTask;
import net.xentany.xbossbar.task.CombinedTask;
import net.xentany.xbossbar.task.RegularTask;
import net.xentany.xbossbar.util.Colorizer;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class BossBarManager {

    private final Main plugin;
    private BossBar bossBar;
    private BossBarTask task;
    private int index = 0;

    public BossBarManager(Main plugin) {
        this.plugin = plugin;
    }

    public void loadBossBars() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("bossbars");
        if (section == null) return;

        String key = (String) section.getKeys(false).toArray()[index];
        index++;
        if (index >= section.getKeys(false).size()) {
            index = 0;
        }

        ConfigurationSection bossBars = section.getConfigurationSection(key);
        if (bossBars == null) return;

        String title = Colorizer.parse(bossBars.getString("title", ""));
        BarColor color = BarColor.valueOf(bossBars.getString("color", "WHITE"));
        BarStyle style = BarStyle.valueOf(bossBars.getString("style", "SOLID"));
        if (bossBar == null) {
            bossBar = Bukkit.createBossBar(title, color, style);
        } else {
            bossBar.setTitle(title);
            bossBar.setColor(color);
            bossBar.setStyle(style);
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Bukkit.getOnlinePlayers().forEach(bossBar::addPlayer);
        });

        BooleanManager manager = new BooleanManager(bossBars);
        boolean still = manager.get("still", false);
        boolean smooth = manager.get("smooth", false);
        boolean invert = manager.get("invert", false);
        if (task != null) {
            task.cancel();
        }
        if (still || smooth) {
            task = new CombinedTask(bossBar, plugin, bossBars.getDouble("delay", 10), invert, still, smooth);
        } else {
            task = new RegularTask(bossBar, plugin, bossBars.getDouble("delay", 10), invert);
        }
        int interval = smooth ? 1 : 20;
        task.runTaskTimerAsynchronously(plugin, 0, interval);
    }

    public void unloadBossBar() {
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar = null;
        }

        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public void addPlayer(Player player) {
        bossBar.addPlayer(player);
    }
}