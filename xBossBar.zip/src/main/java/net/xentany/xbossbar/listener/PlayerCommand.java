package net.xentany.xbossbar.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class PlayerCommand implements Listener {

    @EventHandler
    public void onPlayerCommandPreprocess(@NotNull PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        String command = event.getMessage().substring(1);

        if (command.equalsIgnoreCase("xbossbar")) {
            player.sendMessage("""
                §6This server uses xBossBar ^^,
                §6(C) courtesy of xDev for Spigot
                §ahttps://discord.gg/pSAVbXhcDr!"""
            );
        }
    }
}
